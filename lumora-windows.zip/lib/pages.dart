import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'api.dart';
import 'main.dart';
import 'mcp.dart';
import 'oauth.dart';
import 'store.dart';
import 'ui.dart';

// ---------------------------------------------------------------- API key
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final b = TextEditingController(text: Api.baseUrl);
  final k = TextEditingController(text: Api.apiKey);
  String connMsg = 'Not checked yet', chatMsg = 'Not tested yet';
  bool? connOk, chatOk;
  bool busy = false, show = false;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    b.addListener(_auto);
    k.addListener(_auto);
    if (Api.ready) _check();
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _auto() {
    _t?.cancel();
    if (b.text.trim().isEmpty || k.text.trim().length < 8) return;
    _t = Timer(const Duration(milliseconds: 900), _check);
  }

  Future<void> _check() async {
    if (!mounted) return;
    setState(() {
      busy = true;
      connOk = null;
      chatOk = null;
      connMsg = 'Checking…';
      chatMsg = 'Not tested yet';
    });
    try {
      final m = await Api.check(b.text, k.text);
      if (mounted) {
        setState(() {
          connOk = true;
          connMsg = '${m.length} models found (${Api.proto} format)';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          connOk = false;
          connMsg = Api.explain(e);
        });
      }
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _full() async {
    await _check();
    if (connOk != true || !mounted) return;
    setState(() {
      busy = true;
      chatMsg = 'Sending a short test message…';
    });
    try {
      final m = await Api.testChat();
      if (mounted) {
        setState(() {
          chatOk = true;
          chatMsg = 'Chat works (tested with $m)';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          chatOk = false;
          chatMsg = Api.friendly(e.toString());
        });
      }
    }
    if (mounted) setState(() => busy = false);
  }

  Widget st(bool? ok) => ok == null
      ? (busy
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: accent))
          : const Icon(Icons.remove, color: Colors.black26))
      : Icon(ok ? Icons.check_circle : Icons.error,
          color: ok ? Colors.green.shade700 : Colors.red.shade700);

  @override
  Widget build(BuildContext context) => uiPage('API key', [
        const Padding(
            padding: EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Connect Lumora to your key system. It detects the format and lists every model on the key.',
                style: TextStyle(color: Colors.black54, height: 1.4))),
        uiField(b, 'Base URL',
            hint: 'https://api.example.com', type: TextInputType.url),
        uiField(k, 'API key',
            obscure: !show,
            suffix: IconButton(
                icon: Icon(show ? Icons.visibility_off : Icons.visibility),
                onPressed: () => setState(() => show = !show))),
        uiSection('Status', [
          uiRow('Connection',
              sub: connMsg, icon: Icons.link, trailing: st(connOk)),
          uiRow('Chat test',
              sub: chatMsg,
              icon: Icons.chat_bubble_outline,
              trailing: st(chatOk)),
        ]),
        uiButton(busy ? 'Working…' : 'Test connection and chat',
            busy ? null : _full),
        const SizedBox(height: 10),
        uiButton('Save', () async {
          await Api.save(b.text, k.text);
          if (context.mounted) Navigator.pop(context, true);
        }, primary: false),
      ]);
}

// -------------------------------------------------------------- Dashboard
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Map<String, dynamic>? q;
  int? nModels;
  String err = '';
  bool loading = true;
  final lim = TextEditingController(
      text: Store.limit == 0 ? '' : Store.limit.toString());
  String get _mk => DateTime.now().toIso8601String().substring(0, 7);

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    final qf = Api.quotaInfo();
    try {
      nModels = (await Api.models()).length;
      err = '';
    } catch (e) {
      err = Api.explain(e);
      nModels = null;
    }
    try {
      q = await qf;
    } catch (_) {
      q = {'rows': <List<String>>[], 'raw': null};
    }
    if (mounted) setState(() => loading = false);
  }

  String mask(String k) => k.length <= 10
      ? '••••'
      : '${k.substring(0, 6)}••••${k.substring(k.length - 4)}';
  String fmt(int n) => n >= 1000000
      ? '${(n / 1e6).toStringAsFixed(2)}M'
      : n >= 1000
          ? '${(n / 1e3).toStringAsFixed(1)}K'
          : '$n';

  Widget bar(String name, int v, int mx) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
              child: Text(name,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 14))),
          Text(fmt(v), style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
        const SizedBox(height: 6),
        ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
                minHeight: 5,
                value: mx == 0 ? 0.0 : v / mx,
                color: accent,
                backgroundColor: soft)),
      ]));

  @override
  Widget build(BuildContext context) {
    int ti = 0, to = 0, mx = 1;
    Store.usage.forEach((_, u) {
      ti += u['i'] as int;
      to += u['o'] as int;
      final t = (u['i'] as int) + (u['o'] as int);
      if (t > mx) mx = t;
    });
    final used = Store.monthly[_mk] ?? 0;
    final rows = (q?['rows'] as List?)?.cast<List<String>>() ?? [];
    final raw = q?['raw'] as String?;
    final ok = !loading && err.isEmpty && Api.ready;
    return uiPage('User Dashboard', [
      uiSection('API connection', [
        uiRow('Status',
            trailing: uiVal(
                loading ? 'Checking…' : (ok ? 'Connected' : 'Not connected'),
                c: loading
                    ? null
                    : (ok ? Colors.green.shade700 : Colors.red.shade700))),
        if (err.isNotEmpty)
          uiRow('Problem', sub: err, color: Colors.red.shade700),
        uiRow('Base URL',
            trailing: uiVal(Api.baseUrl.isEmpty ? '—' : Api.baseUrl)),
        uiRow('API key',
            trailing: uiVal(Api.apiKey.isEmpty ? '—' : mask(Api.apiKey))),
        uiRow('Format', trailing: uiVal(Api.proto)),
        uiRow('Models available', trailing: uiVal(nModels?.toString() ?? '—')),
      ]),
      uiSection(
          'Key limits and balance',
          rows.isEmpty
              ? [
                  uiRow(loading ? 'Checking…' : 'Not published by this key system',
                      sub: loading
                          ? null
                          : 'Usage below is counted on this phone.')
                ]
              : [for (final r in rows) uiRow(r[0], trailing: uiVal(r[1]))]),
      if (Api.rate.isNotEmpty)
        uiSection('Rate limits (last request)', [
          for (final e in Api.rate.entries) uiRow(e.key, trailing: uiVal(e.value))
        ]),
      uiSection('Usage on this phone', [
        uiRow('This month', trailing: uiVal('${fmt(used)} tokens')),
        if (Store.limit > 0)
          Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 14),
              child: Column(children: [
                ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                        minHeight: 8,
                        value: used >= Store.limit ? 1.0 : used / Store.limit,
                        color: used >= Store.limit ? Colors.red : accent,
                        backgroundColor: soft)),
                const SizedBox(height: 6),
                Align(
                    alignment: Alignment.centerRight,
                    child: Text('Limit ${fmt(Store.limit)}',
                        style: const TextStyle(
                            fontSize: 12.5, color: Colors.black54))),
              ])),
        uiRow('All time', trailing: uiVal('${fmt(ti)} in · ${fmt(to)} out')),
        uiRow('Chats saved', trailing: uiVal('${Store.chats.length}')),
        for (final e in Store.usage.entries)
          bar(e.key, (e.value['i'] as int) + (e.value['o'] as int), mx),
      ]),
      uiField(lim, 'Monthly token limit (0 = no limit)',
          type: TextInputType.number, onSubmitted: (v) async {
        Store.limit = int.tryParse(v) ?? 0;
        await Store.save();
        if (mounted) setState(() {});
      }),
      if (raw != null)
        uiSection('Raw server response', [
          Padding(padding: const EdgeInsets.all(14), child: SelectableText(raw))
        ]),
      Row(children: [
        Expanded(
            child: uiButton('Backup', () async {
          await Clipboard.setData(ClipboardData(text: Store.exportAll()));
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text('Backup copied. Paste it in a safe place.')));
          }
        }, primary: false)),
        const SizedBox(width: 12),
        Expanded(
            child: uiButton('Restore', () async {
          final d = await Clipboard.getData('text/plain');
          try {
            Store.importAll(d?.text ?? '');
            await Store.save();
            if (mounted) setState(() {});
          } catch (_) {
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Clipboard has no valid backup.')));
            }
          }
        }, primary: false)),
      ]),
    ], actions: [
      IconButton(
          icon: const Icon(Icons.refresh), onPressed: loading ? null : load)
    ]);
  }
}

// -------------------------------------------------------- Persona & memory
class PersonaPage extends StatefulWidget {
  const PersonaPage({super.key});
  @override
  State<PersonaPage> createState() => _PersonaPageState();
}

class _PersonaPageState extends State<PersonaPage> {
  final p = TextEditingController(text: Store.persona);
  final n = TextEditingController(text: Store.notes);
  @override
  Widget build(BuildContext context) => uiPage('Persona & memory', [
        const Padding(
            padding: EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Both are sent with every message, so Lumora always follows your style and remembers what matters to you.',
                style: TextStyle(color: Colors.black54, height: 1.4))),
        uiField(p, 'Persona',
            lines: 4,
            hint: 'e.g. Answer briefly, in Bengali, like a friendly teacher'),
        uiField(n, 'Memory',
            lines: 7, hint: 'Things Lumora should always remember about you'),
        uiButton('Save', () async {
          Store.persona = p.text.trim();
          Store.notes = n.text.trim();
          await Store.save();
          if (context.mounted) Navigator.pop(context);
        }),
      ]);
}

// --------------------------------------------------------------- Connectors
class ConnectorsPage extends StatefulWidget {
  const ConnectorsPage({super.key});
  @override
  State<ConnectorsPage> createState() => _ConnectorsPageState();
}

class _ConnectorsPageState extends State<ConnectorsPage> {
  void snack(String s) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Future<void> add() async {
    final n = TextEditingController(),
        u = TextEditingController(),
        t = TextEditingController();
    final ok = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
              backgroundColor: bg,
              title: const Text('Add connector'),
              content: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  uiField(n, 'Name'),
                  uiField(u, 'Server URL (https)',
                      type: TextInputType.url, hint: 'https://example.com/mcp'),
                  uiField(t, 'Token (leave empty for OAuth)', obscure: true),
                ]),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel')),
                FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: accent),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Add')),
              ],
            ));
    if (ok == true && u.text.trim().isNotEmpty) {
      Store.mcps.add({
        'name': n.text.trim().isEmpty ? u.text.trim() : n.text.trim(),
        'url': u.text.trim(),
        'token': t.text.trim(),
        'on': true
      });
      await Store.save();
      setState(() {});
    }
  }

  Future<void> signIn(Map s) async {
    snack('Opening login...');
    try {
      s['oauth'] = await OAuth.login(s['url']);
      await Store.save();
      snack('Signed in.');
      setState(() {});
    } catch (e) {
      snack('Sign-in failed: ${Api.explain(e)}');
    }
  }

  Future<void> test(Map s) async {
    snack('Connecting...');
    try {
      final c = McpClient(s['url'], await OAuth.token(s));
      await c.init();
      final t = await c.tools();
      snack('Connected. ${t.length} tools: ${t.take(5).map((e) => e['name']).join(', ')}');
    } catch (e) {
      snack('Failed: ${Api.explain(e)}');
    }
  }

  void actions(Map s) => showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      builder: (_) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 8),
            uiRow('Test connection', icon: Icons.bolt, onTap: () {
              Navigator.pop(context);
              test(s);
            }),
            uiRow('Sign in with OAuth', icon: Icons.login, onTap: () {
              Navigator.pop(context);
              signIn(s);
            }),
            uiRow('Remove',
                icon: Icons.delete_outline,
                color: Colors.red.shade700, onTap: () async {
              Navigator.pop(context);
              Store.mcps.remove(s);
              await Store.save();
              setState(() {});
            }),
            const SizedBox(height: 8),
          ])));

  @override
  Widget build(BuildContext context) => uiPage('Connectors (MCP)', [
        const Padding(
            padding: EdgeInsets.only(bottom: 18, left: 4),
            child: Text(
                'Connect remote MCP servers so Lumora can use their tools in chat. Tap a connector for more options.',
                style: TextStyle(color: Colors.black54, height: 1.4))),
        if (Store.mcps.isEmpty)
          uiSection('', [
            uiRow('No connectors yet',
                sub: 'Tap + to add a remote MCP server.',
                icon: Icons.hub_outlined)
          ])
        else
          uiSection('Servers', [
            for (final s in Store.mcps)
              uiRow(s['name'],
                  sub: '${s['url']}${s['oauth'] != null ? '  ·  signed in' : ''}',
                  icon: Icons.hub_outlined,
                  onTap: () => actions(s),
                  trailing: Switch(
                      value: s['on'] == true,
                      activeThumbColor: accent,
                      onChanged: (v) async {
                        s['on'] = v;
                        await Store.save();
                        setState(() {});
                      })),
          ]),
      ],
          fab: FloatingActionButton(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              onPressed: add,
              child: const Icon(Icons.add)));
}

// ----------------------------------------------------------- Prompt library
class PromptsPage extends StatefulWidget {
  const PromptsPage({super.key});
  @override
  State<PromptsPage> createState() => _PromptsPageState();
}

class _PromptsPageState extends State<PromptsPage> {
  Future<void> add() async {
    final c = TextEditingController();
    final t = await showDialog<String>(
        context: context,
        builder: (_) => AlertDialog(
              backgroundColor: bg,
              title: const Text('New prompt'),
              content: SingleChildScrollView(child: uiField(c, 'Prompt', lines: 4)),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel')),
                FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: accent),
                    onPressed: () => Navigator.pop(context, c.text),
                    child: const Text('Save')),
              ],
            ));
    if (t != null && t.trim().isNotEmpty) {
      Store.prompts.add(t.trim());
      await Store.save();
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) => uiPage('Prompt library', [
        if (Store.prompts.isEmpty)
          uiSection('', [
            uiRow('No saved prompts yet',
                sub: 'Tap + to save a prompt you use often.',
                icon: Icons.bookmark_border)
          ])
        else
          uiSection('Tap a prompt to use it', [
            for (var i = 0; i < Store.prompts.length; i++)
              uiRow(Store.prompts[i],
                  icon: Icons.bookmark_border,
                  onTap: () => Navigator.pop(context, Store.prompts[i]),
                  trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () async {
                        Store.prompts.removeAt(i);
                        await Store.save();
                        setState(() {});
                      })),
          ]),
      ],
          fab: FloatingActionButton(
              backgroundColor: accent,
              foregroundColor: Colors.white,
              onPressed: add,
              child: const Icon(Icons.add)));
}

// ------------------------------------------------------------------ Compare
class ComparePage extends StatefulWidget {
  final List<String> models;
  const ComparePage(this.models, {super.key});
  @override
  State<ComparePage> createState() => _ComparePageState();
}

class _ComparePageState extends State<ComparePage> {
  late String a = widget.models.first;
  late String b =
      widget.models.length > 1 ? widget.models[1] : widget.models.first;
  final q = TextEditingController();
  String ra = '', rb = '';
  bool busy = false;

  Future<void> run(bool first) async {
    final m = first ? a : b;
    try {
      await for (final c
          in Api.chat(m, [{'role': 'user', 'content': q.text}], null)) {
        if (!mounted) return;
        setState(() => first ? ra += c : rb += c);
      }
    } catch (e) {
      if (mounted) {
        setState(() => first
            ? ra = Api.friendly(e.toString(), m)
            : rb = Api.friendly(e.toString(), m));
      }
    }
  }

  Future<void> go() async {
    if (q.text.trim().isEmpty || busy) return;
    setState(() {
      busy = true;
      ra = '';
      rb = '';
    });
    await Future.wait([run(true), run(false)]);
    if (mounted) setState(() => busy = false);
  }

  Widget dd(String v, void Function(String) on) => ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 210),
      child: DropdownButton<String>(
          isExpanded: true,
          underline: const SizedBox(),
          value: v,
          items: [
            for (final m in widget.models)
              DropdownMenuItem(
                  value: m, child: Text(m, overflow: TextOverflow.ellipsis))
          ],
          onChanged: (x) => setState(() => on(x!))));

  Widget card(String label, String t) => uiSection(label, [
        Padding(
            padding: const EdgeInsets.all(14),
            child: SelectableText(t.isEmpty ? '…' : t,
                style: const TextStyle(fontSize: 15, height: 1.45, color: ink)))
      ]);

  @override
  Widget build(BuildContext context) => uiPage('Compare models', [
        uiSection('Models', [
          uiRow('Model A', trailing: dd(a, (x) => a = x)),
          uiRow('Model B', trailing: dd(b, (x) => b = x)),
        ]),
        uiField(q, 'Question',
            lines: 2, hint: 'Ask both models the same question'),
        uiButton(busy ? 'Running…' : 'Run both', busy ? null : go),
        const SizedBox(height: 22),
        card('Model A', ra),
        card('Model B', rb),
      ]);
}

// ------------------------------------------------------------------ Preview
class PreviewPage extends StatefulWidget {
  final String html;
  const PreviewPage(this.html, {super.key});
  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> {
  WebViewController? c;
  bool get _web => Platform.isAndroid || Platform.isIOS;
  @override
  void initState() {
    super.initState();
    if (_web) {
      c = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..loadHtmlString(widget.html);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('Preview')),
      body: _web
          ? WebViewWidget(controller: c!)
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: SelectableText(widget.html,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12))));
}

// -------------------------------------------------------------------- Chats
class ChatsPage extends StatefulWidget {
  const ChatsPage({super.key});
  @override
  State<ChatsPage> createState() => _ChatsPageState();
}

class _ChatsPageState extends State<ChatsPage> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    final ql = q.toLowerCase();
    final list = Store.chats
        .where((c) =>
            ql.isEmpty ||
            c.title.toLowerCase().contains(ql) ||
            c.msgs.any((m) => m.text.toLowerCase().contains(ql)))
        .toList();
    return uiPage('Chats', [
      Padding(
          padding: const EdgeInsets.only(bottom: 18),
          child: TextField(
              onChanged: (v) => setState(() => q = v),
              decoration: InputDecoration(
                  hintText: 'Search your chats',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: soft,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none)))),
      if (list.isEmpty)
        uiSection('', [
          uiRow(q.isEmpty ? 'No chats yet' : 'No chats match',
              icon: Icons.chat_bubble_outline)
        ])
      else
        uiSection('', [
          for (final c in list)
            uiRow(c.title,
                sub: '${c.mode} · ${c.msgs.length ~/ 2} messages',
                icon: modeIcon(c.mode),
                onTap: () => Navigator.pop(context, c),
                trailing: IconButton(
                    icon: const Icon(Icons.close, size: 20),
                    onPressed: () async {
                      Store.chats.remove(c);
                      await Store.save();
                      setState(() {});
                    })),
        ]),
    ]);
  }
}

// ---------------------------------------------------------------- Artifacts
class ArtifactsPage extends StatelessWidget {
  const ArtifactsPage({super.key});

  List<Map<String, String>> items() {
    final out = <Map<String, String>>[];
    for (final c in Store.chats) {
      for (final m in c.msgs.where((m) => !m.user && !m.err)) {
        final parts = m.text.split('```');
        for (var i = 1; i < parts.length; i += 2) {
          final raw = parts[i];
          final nl = raw.indexOf('\n');
          final lang = nl > 0 ? raw.substring(0, nl).trim().toLowerCase() : '';
          final src = nl >= 0 ? raw.substring(nl + 1) : raw;
          if (src.trim().length < 20) continue;
          out.add({'lang': lang, 'src': src, 'chat': c.title});
        }
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final list = items();
    return uiPage('Artifacts', [
      const Padding(
          padding: EdgeInsets.only(bottom: 18, left: 4),
          child: Text('Code and web pages Lumora has written in your chats.',
              style: TextStyle(color: Colors.black54, height: 1.4))),
      if (list.isEmpty)
        uiSection('', [
          uiRow('Nothing here yet',
              sub: 'Ask Lumora to write some code or an HTML page.',
              icon: Icons.auto_awesome_motion_outlined)
        ])
      else
        uiSection('', [
          for (final it in list)
            uiRow('${it['lang']!.isEmpty ? 'code' : it['lang']} · ${it['chat']}',
                sub: it['src']!.trim().split('\n').first,
                icon: it['lang'] == 'html' ? Icons.web : Icons.code,
                onTap: () {
                  if (it['lang'] == 'html') {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => PreviewPage(it['src']!)));
                  } else {
                    showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: bg,
                        builder: (_) => SafeArea(
                            child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(mainAxisSize: MainAxisSize.min, children: [
                                  Flexible(
                                      child: SingleChildScrollView(
                                          child: SelectableText(it['src']!,
                                              style: const TextStyle(
                                                  fontFamily: 'monospace',
                                                  fontSize: 13)))),
                                  const SizedBox(height: 12),
                                  uiButton('Copy', () {
                                    Clipboard.setData(
                                        ClipboardData(text: it['src']!));
                                    Navigator.pop(context);
                                  }),
                                ]))));
                  }
                }),
        ]),
    ]);
  }
}
